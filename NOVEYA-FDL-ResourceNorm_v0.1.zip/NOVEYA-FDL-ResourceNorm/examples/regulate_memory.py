from tokenizer import tokenize_norm

print('Token:', tokenize_norm('MEMORY'))
print('Recommendation: rotate caches, snapshot long-term, compress cold data')